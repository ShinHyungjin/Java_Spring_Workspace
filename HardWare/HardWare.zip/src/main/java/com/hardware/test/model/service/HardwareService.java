package com.hardware.test.model.service;

import java.util.List;

public interface HardwareService {
	public List selectAll();
}
